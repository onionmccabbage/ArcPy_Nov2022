"""
Tool Name:     Conditioned Choropleth Maps (CCMaps)
Source Name:   GenerateCCMaps.py
Version:       ArcGIS 10.2
Author:        Environmental Systems Research Institute Inc.
Description:   Computes Conditioned Choropleth Maps
Reference:     Carr, D.B., D. White, A. M. MacEachren. 2005. Conditioned
               Choropleth Maps and Hypothesis Generation. Annals of the
               Association of American Geographers, 95(1): 32-53.
Written by:    Min Sun
Date:          August, 2013
"""

import arcpy
import ast
import os
import numpy

arcpy.env.overwriteOutput = True

def GenerateCCMaps(in_feat, mapped_var, condition_vars, class_breaks,
                   threshold_vals, out_map, out_feat = None,
                   cal_stats = False, weight_field = 'Equal'):
    try:
        ###Data preparing############################################
        arcpy.AddMessage("Data preparing...")
        output_field_schema = ['l_lset', 'l_mset', 'l_hset', 'm_lset', 'm_mset',
                               'm_hset', 'h_lset', 'h_mset', 'h_hset']
        # create the map element list, values of these elements will be changed
        #  according to input, used in Outputmap function
        layout_elements_text = [arcpy.ListFields(in_feat, mapped_var)[0].aliasName] + \
                               [arcpy.ListFields(in_feat, i)[0].aliasName for i in condition_vars] + \
                               class_breaks
        for vals in threshold_vals:
            layout_elements_text += vals

        # store the total number of spatial unit assigned into the current interval
        #  [mapped var, condition var1, condition var2]
            each_quantial_num = [[0, 0, 0], [0, 0, 0], [0, 0, 0]]

        # transfer string input into numberical values, used in map classification
        for i in range(len(class_breaks)):
            class_breaks[i] = ast.literal_eval(class_breaks[i])

        #data structure to store attibute values, used for calculating statistics
        # calculation is only executed when cal_stats == True
        global stats
        stats =  {}
        for i in output_field_schema:
                stats.update({i: {'y': [], condition_vars[0]: [],
                                  condition_vars[1]: [],
                                  'weight': [], 'weight_sum': 0.0,
                                  'RSquared': 0.0, 'mean': 0.0, 'mean_sum': 0.0}})


        in_memory_fc = arcpy.CreateFeatureclass_management('in_memory',
                                                           'in_memort_fc',
                                                           template = in_feat)
        arcpy.CopyFeatures_management(in_feat, in_memory_fc)
        arcpy.MakeFeatureLayer_management(in_memory_fc, "ccmap_dataset")
        #add fields for recording subet result
        existing_fields = [i.name for i in arcpy.ListFields("ccmap_dataset")]
        for i in output_field_schema:
            if not i in existing_fields:
                arcpy.AddField_management("ccmap_dataset", i, "SHORT",
                                          field_alias = 'classes in {}'.format(i))

        ###Data subseting, Unit counting, Statistic data preparing##############

        arcpy.AddMessage("Data subseting...")
        # create data for each data subset
        for i in range(3):
            if i == len(threshold_vals[0]) - 2:
                select_clause1 = '{} >= {} AND {} <= {}'.format(condition_vars[0],
                                                                threshold_vals[0][i],
                                                                condition_vars[0],
                                                                threshold_vals[0][i+1])
            else:
                select_clause1 = '{} >= {} AND {} < {}'.format(condition_vars[0],
                                                               threshold_vals[0][i],
                                                               condition_vars[0],
                                                               threshold_vals[0][i+1])
            for j in range(3):
                if j == len(threshold_vals[1]) - 2:
                    select_clause2 = '{} >= {} AND {} <= {}'.format(condition_vars[1],
                                                                    threshold_vals[1][j],
                                                                    condition_vars[1],
                                                                    threshold_vals[1][j+1])
                else:
                    select_clause2 = '{} >= {} AND {} < {}'.format(condition_vars[1],
                                                                   threshold_vals[1][j],
                                                                   condition_vars[1],
                                                                   threshold_vals[1][j+1])

                select_clause = select_clause1 + " AND " + select_clause2
                arcpy.SelectLayerByAttribute_management("ccmap_dataset",
                                                        "NEW_SELECTION",
                                                        select_clause)

                # go through the spatial unit in current subset panel, do:
                #  1. assign units into classes; 2. count the units fall into
                #  each interval; 3. store data (y, weight) into stats which is
                #  used to calculate mean and r-squared
                with arcpy.da.UpdateCursor("ccmap_dataset",
                                           (mapped_var,
                                            output_field_schema[i*3+j],
                                            condition_vars[0],
                                            condition_vars[1])) as cur:
                    for row in cur:
                        # get the total number of unit within the interval
                        each_quantial_num[1][i] += 1
                        each_quantial_num[2][j] += 1
                        for k in range(len(class_breaks)-1):
                            # for the last interval, query should be min <= x <= max
                            if k == len(class_breaks)-2:
                                if row[0] >= class_breaks[k] and row[0] <= class_breaks[k+1]:
                                    row[1] = k + 1
                                    each_quantial_num[0][k] += 1

                                    #add data to stats dictionary for calculting statistics later
                                    stats[output_field_schema[i*3+j]]['y'].append(row[0])
                                    stats[output_field_schema[i*3+j]][condition_vars[0]].append(row[2])
                                    stats[output_field_schema[i*3+j]][condition_vars[1]].append(row[3])
                                    if len(weight_field) == 0 or weight_field == 'Equal':
                                        stats[output_field_schema[i*3+j]]['weight'].append(1)

                                    break
                                else:
                                    row[1] = 0
                            else:
                                if row[0] >= class_breaks[k] and row[0] < class_breaks[k+1]:
                                    row[1] = k + 1
                                    each_quantial_num[0][k] += 1

                                    #add data to stats dictionary for calculting statistics later
                                    stats[output_field_schema[i*3+j]]['y'].append(row[0])
                                    stats[output_field_schema[i*3+j]][condition_vars[0]].append(row[2])
                                    stats[output_field_schema[i*3+j]][condition_vars[1]].append(row[3])
                                    if len(weight_field) == 0 or weight_field == 'Equal':
                                        stats[output_field_schema[i*3+j]]['weight'].append(1)

                                    break
                                else:
                                    row[1] = 0

                        cur.updateRow(row)

                # fill in the ccmap field for the record fileted out from
                #  dataset at the current window, set class as 0
                arcpy.SelectLayerByAttribute_management("ccmap_dataset",
                                                        "SWITCH_SELECTION")
                with arcpy.da.UpdateCursor("ccmap_dataset",
                                           (output_field_schema[i*3+j])) as cur:
                    for row in cur:
                        row[0] = 0
                        cur.updateRow(row)

        # transfer str to number, will be used in calculating the location of
        #  thumb and label
        for i in range(2):
            for j in range(4):
                threshold_vals[i][j] = ast.literal_eval(threshold_vals[i][j])

        # set weight field in stats if weight is not the defualt value - 1
        for key in stats:
            if len(weight_field) > 0 and weight_field != 'Equal':
                stats[key]['weight'] = stats[key][weight_field]

        arcpy.SelectLayerByAttribute_management("ccmap_dataset",
                                                "CLEAR_SELECTION")
        ###Outputing feature class if needed####################################

        # output the feature class if path is defined
        if len(out_feat) > 0:
            arcpy.CopyFeatures_management("ccmap_dataset", out_feat)
        ###Calculating statistics if needed#####################################
        if cal_stats:
            arcpy.AddMessage("Calculating statistics...")
            CalulateWeightedStats()
        ###Calculating map element locations, Creating CCMaps###################
        arcpy.AddMessage("Creating CCMap...")

        thumb_loc_precent = []
        quantile_text = []
        quantile_text_mapped_var = []
        legend_loc_precent = []
        # thumb relative location for conditioning variable bars
        for i in range(2):
            thumb_loc_precent.append(0.0)
            for j in range(1, 3):
                # (val1 - min) / (max-min)
                thumb_loc_precent.append(float(threshold_vals[i][j] - threshold_vals[i][0]) / \
                                         float(threshold_vals[i][3] - threshold_vals[i][0]))
            thumb_loc_precent.append(1.0)
        # unit count box's content for conditioning variable
        for i in range(1, 3):
            for j in range(3):
                quantile_text.append(float(each_quantial_num[i][j]) /
                                     float(sum(each_quantial_num[i])) * 100.0)
        # mapped variable class legend relative length
        for i in range(1, 4):
            legend_loc_precent.append(float(class_breaks[i] - class_breaks[i-1]) / \
                                      float(class_breaks[3] - class_breaks[0]))
        # unit count box's content for mapped variable
        for i in range(3):
            quantile_text_mapped_var.append(float(each_quantial_num[0][i]) / \
                                            float(sum(each_quantial_num[0])) * 100.0)

        OutputMap("ccmap_dataset", layout_elements_text, quantile_text,
                  thumb_loc_precent, legend_loc_precent,
                  quantile_text_mapped_var, cal_stats, out_map)

    except arcpy.ExecuteError:
        arcpy.AddError(arcpy.GetMessages(2))

    except Exception as err:
        arcpy.AddError(err)

    finally:
        if arcpy.Exists('ccmap_dataset'):
            arcpy.Delete_management('ccmap_dataset')
        if arcpy.Exists(in_memory_fc):
            arcpy.Delete_management(in_memory_fc)

def CalulateWeightedStats():
    wv = 0
    wt = 0
    grand_mean = 0
    grandSS = 0
    for key in stats:
        if len(stats[key]['y']) > 0:
            stats[key]['weight_sum'] = sum(stats[key]['weight'])
            stats[key]['mean'] = numpy.average(stats[key]['y'],
                                               weights = stats[key]['weight'])
            for i in range(len(stats[key]['y'])):
                stats[key]['mean_sum'] += stats[key]['y'][i] * stats[key]['weight'][i]
            wt += stats[key]['weight_sum']
            wv += stats[key]['mean_sum']
    grand_mean = wv / wt

    for key in stats:
        for i in range(len(stats[key]['y'])):
            tmp = stats[key]['y'][i] - grand_mean
            grandSS += stats[key]['weight'][i] * pow(tmp, 2)
    modelSS = 0
    for key in stats:
        if len(stats[key]['y']) > 0:
            if stats[key]['weight_sum'] != 0:
                tmp = float(stats[key]['mean_sum']) / \
                      float(stats[key]['weight_sum']) - grand_mean
                modelSS += stats[key]['weight_sum'] * pow(tmp, 2)
    global rsquared
    if grandSS > 0:
        rsquared = modelSS / grandSS * 100.0

def FormatNumber(valstr):
    value = ast.literal_eval(valstr)
    if isinstance(value, float):
        return '%.2f' % value
    else:
        return valstr

def OutputMap(classified_feat, element_texts, quantile_text, thumb_loc_precent,
              legend_loc_precent, quantile_text_mapped_var, cal_stats, out_map):
    VAR1_BAR_ABCHOR_X_MIN = 1.8246
    VAR1_BAR_WIDTH = 6.6
    VAR2_BAR_ABCHOR_Y_MIN = 1.4002
    VAR2_BAR_HEIGHT = 5.6
    LEGEND_BAR_LEFT = 2.2
    LEGEND_BASE_LENGTH = 5
    LOCATION_TOLERABCE1 = 0.1
    LOCATION_TOLERABCE2 = 0.2

    # map layout template
    mxd = arcpy.mapping.MapDocument(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                                                 'CCMapDocTemplate.mxd'))
    dfs = arcpy.mapping.ListDataFrames(mxd)
    lyr = arcpy.mapping.Layer(classified_feat)
    # a group of layer files for setting up symbology
    symbollyrs = arcpy.mapping.Layer(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                                                  'CCMapSymbologyTemplate.lyr'))

    for i in dfs:
        symbollyr = arcpy.mapping.ListLayers(symbollyrs,
                                             ('*' + i.name + '*'))[0]
        arcpy.mapping.UpdateLayer(i, lyr, symbollyr, True)
        arcpy.mapping.AddLayer(i, lyr)

    # customize layout elements
    text_element_names = ['dependent_var_name',
                         'condition_var1_name',
                         'condition_var2_name',
                         'dependent_var_min1', 'dependent_var_min2',
                         'dependent_var_min3', 'dependent_var_max3',
                         'var1_min1', 'var1_min2', 'var1_min3', 'var1_max3',
                         'var2_min1', 'var2_min2', 'var2_min3', 'var2_max3',
                         'var1_low_quantile', 'var1_medium_quantile',
                         'var1_high_quantile',
                         'var2_low_quantile', 'var2_medium_quantile',
                         'var2_high_quantile',
                         'var1_bar1', 'var1_bar2',
                         'var2_bar1', 'var2_bar2',
                         'class1', 'class2', 'class3',
                         'mapped_var_low_quantile',
                         'mapped_var_medium_quantile',
                         'mapped_var_high_quantile']

    # set the locatin and content of quantile box for horizontal axis
    for i in range(15, 18):
        elm = arcpy.mapping.ListLayoutElements(mxd, 'TEXT_ELEMENT',
                                               text_element_names[i])[0]
        if quantile_text[i-15] == 0.0:
            elm.elementPositionY = -1
        else:
            elm.text = "{}%".format("%.0f" % quantile_text[i-15])
            elm.elementPositionX = (thumb_loc_precent[i-14] + thumb_loc_precent[i-15]) / 2 * \
                                    VAR1_BAR_WIDTH + VAR1_BAR_ABCHOR_X_MIN - LOCATION_TOLERABCE1

    # set the locatin and content of quantile box for vertical axis
    for i in range(18, 21):
        elm = arcpy.mapping.ListLayoutElements(mxd, 'TEXT_ELEMENT',
                                               text_element_names[i])[0]
        if quantile_text[i-15] == 0.0:
            elm.elementPositionX = -1
        else:
            elm.text = "{}%".format("%.0f" % quantile_text[i-15])
            elm.elementPositionY = (thumb_loc_precent[i-14] + thumb_loc_precent[i-13]) / 2 * \
                                    VAR2_BAR_HEIGHT + VAR2_BAR_ABCHOR_Y_MIN - LOCATION_TOLERABCE1

    # set the location of thumb on horizontal axis
    for i in range(2):
        elm = arcpy.mapping.ListLayoutElements(mxd, 'GRAPHIC_ELEMENT',
                                               text_element_names[i+21])[0]
        elm.elementPositionX = thumb_loc_precent[i+1] * \
                               VAR1_BAR_WIDTH + VAR1_BAR_ABCHOR_X_MIN

    # set the location of thumb on vertical axis
    for i in range(2):
        elm = arcpy.mapping.ListLayoutElements(mxd, 'GRAPHIC_ELEMENT',
                                               text_element_names[i+23])[0]
        elm.elementPositionY = thumb_loc_precent[i+5] * \
                               VAR2_BAR_HEIGHT + VAR2_BAR_ABCHOR_Y_MIN

    # set the location and content of interval break values for horizontal axis
    for i in range(7, 11):
        elm = arcpy.mapping.ListLayoutElements(mxd, 'TEXT_ELEMENT',
                                               text_element_names[i])[0]
        elm.text = FormatNumber(element_texts[i])
        elm.elementPositionX = thumb_loc_precent[i-7] * \
                               VAR1_BAR_WIDTH + VAR1_BAR_ABCHOR_X_MIN

    # set the location and content of interval break values for vertical axis
    for i in range(11, 15):
        elm = arcpy.mapping.ListLayoutElements(mxd, 'TEXT_ELEMENT',
                                               text_element_names[i])[0]
        elm.text = FormatNumber(element_texts[i])
        elm.elementPositionY = thumb_loc_precent[i-7] * VAR2_BAR_HEIGHT + \
                                    VAR2_BAR_ABCHOR_Y_MIN - LOCATION_TOLERABCE1

    # set legend of mapped variable
    previous_total_length = 0.0
    class_break_loc = [LEGEND_BAR_LEFT]
    for i in range(25, 28):
        elm = arcpy.mapping.ListLayoutElements(mxd, 'GRAPHIC_ELEMENT',
                                               text_element_names[i])[0]
        elm.elementWidth = legend_loc_precent[i-25] * LEGEND_BASE_LENGTH
        elm.elementPositionX = LEGEND_BAR_LEFT + previous_total_length
        previous_total_length += elm.elementWidth
        class_break_loc.append(LEGEND_BAR_LEFT + previous_total_length)

    #set label of mapped variable
    for i in range(3, 7):
        elm = arcpy.mapping.ListLayoutElements(mxd, 'TEXT_ELEMENT',
                                               text_element_names[i])[0]
        elm.text = FormatNumber(element_texts[i])
        if i == 3:
            elm.elementPositionX = class_break_loc[i-3] - elm.elementWidth
        else:
            elm.elementPositionX = class_break_loc[i-3]

    # set quantile of mapped variable
    for i in range(28, 31):
        elm = arcpy.mapping.ListLayoutElements(mxd, 'TEXT_ELEMENT',
                                               text_element_names[i])[0]
        if quantile_text_mapped_var[i-28] == 0.0:
            elm.elementPositionX = -1
        else:
            elm.text = "{}%".format("%.0f" % quantile_text_mapped_var[i-28])
            elm.elementPositionX = float(class_break_loc[i-27] + \
                                         class_break_loc[i-28]) / 2.0 - LOCATION_TOLERABCE2

    # set variable titles
    for i in range(3):
        elm = arcpy.mapping.ListLayoutElements(mxd, 'TEXT_ELEMENT',
                                               text_element_names[i])[0]
        elm.text = element_texts[i]

    if cal_stats:
        # add statistical values to the box on right top
        for key in stats:
            elm = arcpy.mapping.ListLayoutElements(mxd, 'TEXT_ELEMENT',
                                                   "{}_stats".format(key))[0]
            if len(stats[key]['y']) > 0:
                elm.text = "{}".format("%.2f" % stats[key]['mean'])
            else:
                elm.elementPositionX = -1
        if rsquared:
            arcpy.mapping.ListLayoutElements(mxd,
                                            'TEXT_ELEMENT',
                                            'rsquared')[0].text = "Rsquared: {}%".format("%.2f" % rsquared)
        else:
            arcpy.mapping.ListLayoutElements(mxd,
                                        'TEXT_ELEMENT',
                                        'rsquared')[0].elementPositionX = -1
    else:
        for key in stats:
            elm = arcpy.mapping.ListLayoutElements(mxd, 'TEXT_ELEMENT',
                                                   "{}_stats".format(key))[0]
            elm.elementPositionX = -1
        arcpy.mapping.ListLayoutElements(mxd,
                                        'TEXT_ELEMENT',
                                        'rsquared')[0].elementPositionX = -1

    arcpy.mapping.ExportToPDF(mxd, out_map, resolution = 300)

if __name__ == '__main__':
    GenerateCCMaps(arcpy.GetParameterAsText(0), # input feature
                   # mapped var
                   arcpy.GetParameterAsText(2),
                   # conditioned var 1 & 2
                   [arcpy.GetParameterAsText(3), arcpy.GetParameterAsText(4)],
                   # values of mapped var
                   arcpy.GetParameterAsText(5).split(";"),
                   # values of conditioned vars
                   [arcpy.GetParameterAsText(6).split(";"),
                    arcpy.GetParameterAsText(7).split(";")],
                   # output image path
                   arcpy.GetParameterAsText(1),
                   # output feature path (optional)
                   arcpy.GetParameterAsText(10),
                   arcpy.GetParameter(8),
                   arcpy.GetParameterAsText(9))
