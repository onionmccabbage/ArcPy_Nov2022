import arcpy
mypath = "C:/Lessons/PythonDesc"
arcpy.env.workspace = mypath



