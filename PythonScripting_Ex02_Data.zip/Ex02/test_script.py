# Simple test script
print("GIS is cool")
