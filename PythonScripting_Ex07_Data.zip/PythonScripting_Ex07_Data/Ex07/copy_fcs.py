import arcpy
import os
arcpy.env.workspace = "C:/PythonPro/Ex07"
arcpy.env.overwriteOutput = True
fgdb = "Study.gdb"
fclist = arcpy.ListFeatureClasses()
for fc in fclist:
    desc = arcpy.da.Describe(fc)
    outfc = os.path.join(fgdb, desc["baseName"])
    arcpy.CopyFeatures_management(fc, outfc)
