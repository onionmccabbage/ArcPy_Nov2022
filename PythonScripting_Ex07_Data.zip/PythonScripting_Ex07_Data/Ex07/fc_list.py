import arcpy
arcpy.env.workspace = "C:/PythonPro/Ex07"
fclist = arcpy.ListFeatureClasses()
for fc in fclist
    desc = arcpy.da.describe(fc)
    print(f'{desc["baseName"]}: {des["shapeType"]}')
